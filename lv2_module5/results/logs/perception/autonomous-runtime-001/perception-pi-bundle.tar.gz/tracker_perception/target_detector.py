"""ROS Image를 받아 기존 검출기의 결과를 PointStamped로 발행한다.

저장소 루트에서 시스템 Python으로 실행한다:
  /usr/bin/python3 -m tracker_perception.target_detector \
      --ros-args --params-file config/perception.yaml
"""

import math

import cv2
import rclpy
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import PointStamped
from rcl_interfaces.msg import ParameterDescriptor
from rclpy.executors import ExternalShutdownException
from rclpy.node import Node
from rclpy.qos import (
    DurabilityPolicy,
    HistoryPolicy,
    QoSProfile,
    ReliabilityPolicy,
)
from sensor_msgs.msg import Image

from .detector import DetectorConfig, detect


class TargetDetector(Node):
    def __init__(self):
        super().__init__("target_detector")
        defaults = {
            "image_topic": "/camera/camera/color/image_raw",
            "target_topic": "/target",
            "input_encoding": "rgb8",
            "width": 640,
            "height": 480,
            "hsv_lower": [92, 80, 26],
            "hsv_upper": [120, 255, 255],
            "kernel_size": 5,
            "min_area_px": 400,
        }
        # 실험 중 설정 변경을 막는다. 변경하려면 YAML을 수정하고 재시작한다.
        params = {
            name: self.declare_parameter(
                name, value, ParameterDescriptor(read_only=True)
            ).value
            for name, value in defaults.items()
        }
        lower, upper = tuple(params["hsv_lower"]), tuple(params["hsv_upper"])
        if len(lower) != 3 or len(upper) != 3:
            raise ValueError("HSV 하한·상한에는 각각 H,S,V 세 값이 필요합니다.")
        for lo, hi, limit in zip(lower, upper, (179, 255, 255)):
            if not 0 <= lo <= hi <= limit:
                raise ValueError("HSV 범위는 0 <= 하한 <= 상한 <= H179/SV255여야 합니다.")
        kernel = params["kernel_size"]
        if kernel < 1 or kernel % 2 != 1:
            raise ValueError("kernel_size는 1 이상의 홀수여야 합니다.")
        area = float(params["min_area_px"])
        if not math.isfinite(area) or area <= 0:
            raise ValueError("min_area_px는 0보다 큰 유한값이어야 합니다.")
        if params["input_encoding"] not in ("rgb8", "bgr8"):
            raise ValueError("input_encoding은 rgb8 또는 bgr8이어야 합니다.")
        if params["width"] < 1 or params["height"] < 1:
            raise ValueError("요청 width/height는 양수여야 합니다.")
        if not params["image_topic"] or not params["target_topic"]:
            raise ValueError("입력 및 출력 토픽은 비어 있을 수 없습니다.")

        self.cfg = DetectorConfig(
            hsv_lower=lower,
            hsv_upper=upper,
            kernel_size=kernel,
            min_area_px=area,
            input_encoding=params["input_encoding"],
        )
        self.bridge = CvBridge()
        self.requested_size = (params["width"], params["height"])
        self.last_size = None
        self.last_found = None
        qos = QoSProfile(
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
        )
        self.target_pub = self.create_publisher(
            PointStamped, params["target_topic"], qos
        )
        self.image_sub = self.create_subscription(
            Image, params["image_topic"], self.on_image, qos
        )
        self.get_logger().info(
            f"TARGET_NODE_READY: {params['image_topic']} -> {params['target_topic']}; "
            f"HSV={lower}..{upper}, kernel={kernel}, min_area={area}; "
            "best_effort / keep_last 1; 영상 수신 대기"
        )

    def on_image(self, msg):
        # 손상된 입력은 정상 영상의 '목표 없음'과 구분하고 발행하지 않는다.
        if msg.encoding not in ("rgb8", "bgr8") or msg.width < 1 or msg.height < 1:
            self.get_logger().error("rgb8/bgr8 컬러 영상이 아니거나 크기가 잘못되었습니다.")
            return
        try:
            frame = self.bridge.imgmsg_to_cv2(
                msg, desired_encoding=self.cfg.input_encoding
            )
            if frame.shape != (msg.height, msg.width, 3) or frame.dtype.name != "uint8":
                raise ValueError("변환된 배열의 크기 또는 자료형이 올바르지 않습니다.")
            detection, _ = detect(frame, self.cfg)
        except (CvBridgeError, cv2.error, ValueError, TypeError) as exc:
            self.get_logger().error(f"영상 처리 실패, 결과 발행 생략: {exc}")
            return

        # 타이머나 이전 결과 재사용 없이 새 영상 콜백에서만 한 번 발행한다.
        target = PointStamped()
        target.header = msg.header
        target.point.x = float(detection.ex)
        target.point.y = float(detection.ey)
        target.point.z = float(detection.area_ratio)
        self.target_pub.publish(target)

        size = (frame.shape[1], frame.shape[0])
        if size != self.last_size:
            self.get_logger().info(
                f"IMAGE_RECEIVED: actual={size}, requested={self.requested_size}, "
                f"encoding={msg.encoding}, frame_id={msg.header.frame_id}; "
                "정규화는 실제 크기 기준"
            )
            self.last_size = size
        if detection.found != self.last_found:
            self.get_logger().info(
                f"TARGET_STATE: found={detection.found}, "
                f"ex={detection.ex:+.6f}, ey={detection.ey:+.6f}, "
                f"area_ratio={detection.area_ratio:.6f}"
            )
            self.last_found = detection.found


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = TargetDetector()
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
